--------------------------------------------------------------------------------

  COPYRIGHTS

--------------------------------------------------------------------------------

The photos «Sound of Silence» and «No Man Is an Island» are Copyright 2007-2008, Daniel Gasienica.
They are released under the Creative Commons Attribution-Noncommercial-No Derivative Works 2.0 license.
<http://creativecommons.org/licenses/by-nc-nd/2.0/deed.en>

The Google Maps sample OpenZoom descriptors are distributed only for demonstration purposes
and you should refer to the Google Maps Terms of Use before using them.
<http://code.google.com/apis/maps/terms.html>

For more information about the OpenStreetMap project, visit
<http://www.openstreetmap.org/>


--------------------------------------------------------------------------------

  CREATING IMAGES

--------------------------------------------------------------------------------

«Sound of Silence» was created using Microsoft Deep Zoom Composer.
«No Man Is an Island» was created using ZoomifyEZ.
To create your own multi-scale images, use one of the following tools:

***

Deep Zoom: Deep Zoom Composer (Windows)
<http://microsoft.com/downloads/details.aspx?familyid=457b17b7-52bf-4bda-87a3-fa8a4673f8bf>

***

Zoomify EZ (Windows & Mac OS X)
<http://www.zoomify.com/express.htm>

***

Seadragon.py (Python: Windows, Mac OS X & Linux )
http://blog.kapilt.com/2008/11/30/sharing-large-images-openlayers-gsiv-modestmaps-deepzoom-and-python/

<http://kapilt.com/files/seadragon.py>

***